/*

- Copy your game project code into this file
- for the p5.Sound library look here https://p5js.org/reference/#/libraries/p5.sound
- for finding cool sounds perhaps look here
https://freesound.org/


*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var scrollPos;
var gameChar_world_x;

var isLeft;
var isRight;
var isFalling;
var isPlummeting;

var trees_x;
var clouds;
var mountains;
var canyons;
var collectables;

var game_score;
var flagpole;
var lives;

var jumpSound;
var collectSound;
var winSound;

var platforms;

function preload() {
  // The extension I used here is adding sound to my game. I added three types of sounds i.e, when the game character jumps, collects a coin and wins the game by reaching the flagpole. Finding the write sound was quite difficult since there were thousands to choose from and editing some of them so that sound is shorter and desirable. By implementing this extension I learned how to add sound to my code. I learnt how to edit the code for my sound to fit in.
    
  soundFormats('mp3', 'wav');
    
  //load your sounds here
  jumpSound = loadSound('assets/jump.wav');
  collectSound = loadSound('assets/collect.wav');
  winSound = loadSound('assets/win.wav');
  winSound.setVolume(0.1);
  jumpSound.setVolume(0.1);
  collectSound.setVolume(0.1);
}


function setup() {
  createCanvas(1024, 576);
  floorPos_y = height * 3 / 4;
  lives = 3;
  startGame();

}


function draw() {
  background(100, 155, 255); // fill the sky blue

  noStroke();
  fill(34, 139, 35);
  rect(0, floorPos_y, width, height / 4); // draw some green ground

  push();
  translate(scrollPos, 0);

  // Draw clouds.
  drawClouds();

  // Draw mountains.
  drawMountains();

  // Draw trees.
  drawTrees();

  //The Extension I used here is adding platforms to my game. I added two platforms over the canyons to make it easier to move across without falling into the canyon and loosing a life. Figuring out the right place for the platforms was a bit hard. Editing the code so that the game character won't fall off if it's too near the edges was challenging but I managed to pull through. I learnt how to implement the factory pattern into my code.
    
  // Draw platforms.
  for (var i = 0; i < platforms.length; i++) {
    platforms[i].draw();
  }

  // Draw canyons.
  for (var i = 0; i < canyons.length; i++) {
    drawCanyon(canyons[i]);
    checkCanyon(canyons[i]);
  }

  // Draw collectable items.
  for (var i = 0; i < collectables.length; i++) {
    if (collectables[i].isFound == false) {
      drawCollectable(collectables[i]);
      checkCollectable(collectables[i]);
    }
  }

  renderFlagpole();

  pop();

  // Draw game character.

  drawGameChar();

  // Score Counter
  fill(255);
  noStroke();
  textStyle(ITALIC);
  textSize(20);
  text("COINS: " + game_score, 20, 20);
  text("LIVES: " + lives, 20, 50);

  //Display
  if (lives < 1) {
    fill(0, 0, 0);
    textStyle(ITALIC);
    textSize(60);
    text("Game over. Press space to continue.", 20, 300);
    return;
  }
  if (flagpole.isReached == true) {
    fill(0, 0, 0);
    textStyle(ITALIC);
    textSize(50);
    text("Level complete. Press space to continue", 20, 300);
    return;
  }




  // Logic to make the game character move or the background scroll.
  if (isLeft) {
    if (gameChar_x > width * 0.2) {
      gameChar_x -= 5;
    } else {
      scrollPos += 5;
    }
  }

  if (isRight) {
    if (gameChar_x < width * 0.8) {
      gameChar_x += 5;
    } else {
      scrollPos -= 5; // negative for moving against the background
    }
  }

  // Logic to make the game character rise and fall.
  if (gameChar_y < floorPos_y) {
    var isContact = false;
    for (var i = 0; i < platforms.length; i++) {
      if (platforms[i].checkContact(gameChar_world_x, gameChar_y - 5)) {
        isContact = true;
        break;
      }
    }
    if (isContact == false) {
      isFalling = true;
      gameChar_y += 1;
    }
  } else {
    isFalling = false;
  }

  // Update real position of gameChar for collision detection.
  gameChar_world_x = gameChar_x - scrollPos;

  if (flagpole.isReached == false) {
    checkFlagpole();

  }
  checkPlayerDie();

}

function checkPlayerDie() {
  if (gameChar_y > height) {
    lives--;
    if (lives > 0) {
      startGame();
    }
  }
}

function startGame() {
  gameChar_x = width / 2;
  gameChar_y = floorPos_y;

  // Variable to control the background scrolling.
  scrollPos = 0;

  // Variable to store the real position of the gameChar in the game
  // world. Needed for collision detection.
  gameChar_world_x = gameChar_x - scrollPos;

  // Boolean variables to control the movement of the game character.
  isLeft = false;
  isRight = false;
  isFalling = false;
  isPlummeting = false;

  // Initialise arrays of scenery objects.
  trees_x = [-300, 50, 300, 530, 1000, 1400, 1780, 2100, 2650];

  clouds = [{
      x_pos: 60,
      y_pos: 90
    },
    {
      x_pos: 400,
      y_pos: 66
    },
    {
      x_pos: 700,
      y_pos: 75
    },
    {
      x_pos: 950,
      y_pos: 40
    },
    {
      x_pos: -700,
      y_pos: 75
    },
    {
      x_pos: -950,
      y_pos: 40
    },
    {
      x_pos: 1280,
      y_pos: 75
    },
    {
      x_pos: 1550,
      y_pos: 95
    },
    {
      x_pos: 1890,
      y_pos: 70
    },
    {
      x_pos: 2270,
      y_pos: 62
    },
    {
      x_pos: 2650,
      y_pos: 90
    },
  ];

  mountains = [{
      x_pos: 50,
      y_pos: 100
    },
    {
      x_pos: 670,
      y_pos: 100
    },
    {
      x_pos: 899,
      y_pos: 100
    },
    {
      x_pos: -470,
      y_pos: 100
    },
    {
      x_pos: -970,
      y_pos: 100
    },
    {
      x_pos: 1070,
      y_pos: 100
    },
    {
      x_pos: 2220,
      y_pos: 100
    },
  ];

  canyons = [{
      x_pos: 160,
      width: 100
    },
    {
      x_pos: 600,
      width: 100
    },
    {
      x_pos: 1060,
      width: 100
    },
    {
      x_pos: 2000,
      width: 100
    },
    {
      x_pos: -560,
      width: 100
    },
    {
      x_pos: -1000,
      width: 100
    },
  ]

  collectables = [{
      x_pos: 40,
      y_pos: 420,
      size: 50,
      isFound: false
    },
    {
      x_pos: 800,
      y_pos: 420,
      size: 50,
      isFound: false
    },
    {
      x_pos: 1240,
      y_pos: 420,
      size: 50,
      isFound: false
    },
    {
      x_pos: -800,
      y_pos: 420,
      size: 50,
      isFound: false
    },
    {
      x_pos: -340,
      y_pos: 420,
      size: 50,
      isFound: false
    },
    {
      x_pos: 2200,
      y_pos: 420,
      size: 50,
      isFound: false
    },
    {
      x_pos: 1070,
      y_pos: 335,
      size: 50,
      isFound: false
    },
  ];

  platforms = [];

  platforms.push(createPlatforms(180, floorPos_y - 100, 150));
  platforms.push(createPlatforms(1020, floorPos_y - 80, 130));

  game_score = 0;

  flagpole = {
    isReached: false,
    x_pos: 2950
  };
}


// ---------------------
// Key control functions
// ---------------------

function keyPressed() {

  if (keyCode == 37) {
    isLeft = true;
  } else if (keyCode == 39) {
    isRight = true;
  } else if (keyCode == 38 || keyCode == 32) {
    gameChar_y -= 50;
    isFalling = true;
    jumpSound.play();
  }


}

function keyReleased() {

  if (keyCode == 37) {
    isLeft = false;
  } else if (keyCode == 39) {
    isRight = false;
  }
}


// ------------------------------
// Game character render function
// ------------------------------

// Function to draw the game character.

function drawGameChar() {
  //the game character
  if (isLeft && isFalling) {
    // add your jumping-left code
    stroke(20);
    fill(240, 160, 50);
    ellipse(gameChar_x, gameChar_y - 60, 30, 30);
    fill(0);
    ellipse(gameChar_x - 6, gameChar_y - 62, 5, 5);
    ellipse(gameChar_x + 3, gameChar_y - 62, 5, 5);
    stroke(1);
    line(gameChar_x - 6, gameChar_y - 54, gameChar_x + 3, gameChar_y - 54);
    stroke(20);
    //body
    fill(200, 50, 40);
    rect(gameChar_x - 12, gameChar_y - 45, 24, 30);
    //legs
    fill(0);
    rect(gameChar_x - 12, gameChar_y - 15, 8, 10);
    rect(gameChar_x + 4, gameChar_y - 15, 8, 10);
    //hands
    fill(240, 160, 50);
    rect(gameChar_x - 10, gameChar_y - 45, -17, 10);
    rect(gameChar_x + 10, gameChar_y - 40, 10, -17);

  } else if (isRight && isFalling) {
    // add your jumping-right code
    stroke(20);
    fill(240, 160, 50);
    ellipse(gameChar_x, gameChar_y - 60, 30, 30);
    fill(0);
    ellipse(gameChar_x - 2, gameChar_y - 62, 5, 5);
    ellipse(gameChar_x + 7, gameChar_y - 62, 5, 5);
    stroke(1);
    line(gameChar_x - 2, gameChar_y - 54, gameChar_x + 7, gameChar_y - 54);
    stroke(20);
    //body
    fill(200, 50, 40);
    rect(gameChar_x - 12, gameChar_y - 45, 24, 30);
    //legs
    fill(0);
    rect(gameChar_x - 12, gameChar_y - 15, 8, 10);
    rect(gameChar_x + 4, gameChar_y - 15, 8, 10);
    //hands
    fill(240, 160, 50);
    rect(gameChar_x - 20, gameChar_y - 40, 10, -17);
    rect(gameChar_x + 26, gameChar_y - 45, -17, 10);


  } else if (isLeft) {
    // add your walking left code
    stroke(20);
    fill(240, 160, 50);
    ellipse(gameChar_x, gameChar_y - 60, 30, 30);
    fill(0);
    ellipse(gameChar_x - 6, gameChar_y - 62, 5, 5);
    ellipse(gameChar_x + 3, gameChar_y - 62, 5, 5);
    stroke(1);
    line(gameChar_x - 6, gameChar_y - 54, gameChar_x + 3, gameChar_y - 54);
    stroke(20);
    //body
    fill(200, 50, 40);
    rect(gameChar_x - 12, gameChar_y - 45, 24, 30);
    //legs
    fill(0);
    rect(gameChar_x - 12, gameChar_y - 15, 8, 17);
    rect(gameChar_x + 4, gameChar_y - 15, 8, 17);
    //hands
    fill(240, 160, 50);
    rect(gameChar_x - 10, gameChar_y - 45, -17, 10);
    rect(gameChar_x + 11.5, gameChar_y - 45, -17, 10);

  } else if (isRight) {
    // add your walking right code
    stroke(20);
    fill(240, 160, 50);
    ellipse(gameChar_x, gameChar_y - 60, 30, 30);
    fill(0);
    ellipse(gameChar_x - 2, gameChar_y - 62, 5, 5);
    ellipse(gameChar_x + 7, gameChar_y - 62, 5, 5);
    stroke(1);
    line(gameChar_x - 2, gameChar_y - 54, gameChar_x + 7, gameChar_y - 54);
    stroke(20);
    //body
    fill(200, 50, 40);
    rect(gameChar_x - 12, gameChar_y - 45, 24, 30);
    //legs
    fill(0);
    rect(gameChar_x - 12, gameChar_y - 15, 8, 17);
    rect(gameChar_x + 4, gameChar_y - 15, 8, 17);
    //hands
    fill(240, 160, 50);
    rect(gameChar_x + 5, gameChar_y - 45, -17, 10);
    rect(gameChar_x + 26, gameChar_y - 45, -17, 10);


  } else if (isFalling || isPlummeting) {
    // add your jumping facing forwards code
    stroke(20);
    fill(240, 160, 50);
    ellipse(gameChar_x, gameChar_y - 60, 30, 30);
    fill(0);
    ellipse(gameChar_x - 4, gameChar_y - 62, 5, 5);
    ellipse(gameChar_x + 5, gameChar_y - 62, 5, 5);
    stroke(1);
    line(gameChar_x - 4, gameChar_y - 54, gameChar_x + 5, gameChar_y - 54);
    stroke(20);
    //body
    fill(200, 50, 40);
    rect(gameChar_x - 12, gameChar_y - 45, 24, 30);
    //legs
    fill(0);
    rect(gameChar_x - 12, gameChar_y - 15, 8, 12);
    rect(gameChar_x + 4, gameChar_y - 15, 8, 12);
    //hands
    fill(240, 160, 50);
    rect(gameChar_x - 20, gameChar_y - 40, 10, -17);
    rect(gameChar_x + 10, gameChar_y - 40, 10, -17);


  } else {
    // add your standing front facing code
    stroke(20);
    fill(240, 160, 50);
    ellipse(gameChar_x, gameChar_y - 60, 30, 30);
    fill(0);
    ellipse(gameChar_x - 4, gameChar_y - 62, 5, 5);
    ellipse(gameChar_x + 5, gameChar_y - 62, 5, 5);
    stroke(1);
    line(gameChar_x - 4, gameChar_y - 54, gameChar_x + 5, gameChar_y - 54);
    stroke(20);
    //body
    fill(200, 50, 40);
    rect(gameChar_x - 12, gameChar_y - 45, 24, 30);
    //legs
    fill(0);
    rect(gameChar_x - 12, gameChar_y - 15, 8, 17);
    rect(gameChar_x + 4, gameChar_y - 15, 8, 17);
    //hands
    fill(240, 160, 50);
    rect(gameChar_x - 20, gameChar_y - 45, 10, 17);
    rect(gameChar_x + 10, gameChar_y - 45, 10, 17);

  }
}

// ---------------------------
// Background render functions
// ---------------------------

// Function to draw cloud objects.
function drawClouds() {
  for (var i = 0; i < clouds.length; i++) {
    noStroke();
    fill(255, 255, 255);
    ellipse(clouds[i].x_pos + 100, clouds[i].y_pos + 50, 130, 100);
    ellipse(clouds[i].x_pos + 30, clouds[i].y_pos + 50, 90, 60);
    ellipse(clouds[i].x_pos + 180, clouds[i].y_pos + 50, 90, 60);
  }
}

// Function to draw mountains objects.
function drawMountains() {
  for (var i = 0; i < mountains.length; i++) {
    fill(139, 69, 19);
    //triangle(500,260,300,432,700,432);
    triangle(mountains[i].x_pos + 200, mountains[i].y_pos + 160, mountains[i].x_pos + 100, mountains[i].y_pos + 332, mountains[i].x_pos + 400, mountains[i].y_pos + 332);
    fill(145, 69, 19);
    //triangle(570,280,360,432,720,432);
    triangle(mountains[i].x_pos + 270, mountains[i].y_pos + 180, mountains[i].x_pos + 160, mountains[i].y_pos + 332, mountains[i].x_pos + 420, mountains[i].y_pos + 332);
  }
}

// Function to draw trees objects.
function drawTrees() {
  for (var i = 0; i < trees_x.length; i++) {
    //tree  trunk
    fill(165, 42, 42);
    rect(trees_x[i], floorPos_y - 150, 60, 150);
    //tree branches
    fill(0, 155, 0);
    triangle(trees_x[i] - 50, floorPos_y - 100, trees_x[i] + 30, floorPos_y - 200, trees_x[i] + 110, floorPos_y - 100);
    triangle(trees_x[i] - 50, floorPos_y - 150, trees_x[i] + 30, floorPos_y - 250, trees_x[i] + 110, floorPos_y - 150);
  }
}


// ---------------------------------
// Canyon render and check functions
// ---------------------------------

// Function to draw canyon objects.

function drawCanyon(t_canyon) {


  noStroke();
  fill(100, 155, 255);
  rect(t_canyon.x_pos, t_canyon.width + 332, 100, 144);
  fill(30, 144, 255);
  rect(t_canyon.x_pos, t_canyon.width + 342, 100, 144);
}

// Function to check character is over a canyon.

function checkCanyon(t_canyon) {
  if (gameChar_y >= floorPos_y) {
    if ((gameChar_world_x > t_canyon.x_pos && gameChar_y >= floorPos_y) && (gameChar_world_x < t_canyon.x_pos + 120 && gameChar_y >= floorPos_y)) {
      isPlummeting = true;
    }
  }
  if (isPlummeting == true) {
    gameChar_y += 1;
  }
}

// ----------------------------------
// Collectable items render and check functions
// ----------------------------------

// Function to draw collectable objects.

function drawCollectable(t_collectable) {
  fill(255, 215, 0),
    stroke(0);
  ellipse(t_collectable.x_pos, t_collectable.y_pos, t_collectable.size);
  fill(0, 0, 0);
  textSize(20);
  textFont('Italic');
  textAlign(CENTER);
  text("$", t_collectable.x_pos, t_collectable.y_pos + 4);
  noStroke();


}

// Function to check character has collected an item.

function checkCollectable(t_collectable) {
  if (dist(gameChar_world_x, gameChar_y, t_collectable.x_pos, t_collectable.y_pos) < 20) {
    t_collectable.isFound = true;
    game_score += 10;
    collectSound.play();
  }
}

function renderFlagpole() {
  push();
  stroke(100);
  strokeWeight(5);
  line(flagpole.x_pos, floorPos_y, flagpole.x_pos, floorPos_y - 250);
  fill(160, 70, 110);
  stroke(100, 0, 0);
  if (flagpole.isReached == true) {
    rect(flagpole.x_pos, floorPos_y - 250, 35, 35);
  } else {
    rect(flagpole.x_pos, floorPos_y - 50, 35, 35);

  }

  pop();
}

function checkFlagpole() {
  var d = abs(gameChar_world_x - flagpole.x_pos);

  if (d < 15) {
    flagpole.isReached = true;
    winSound.play();
  }

}

function createPlatforms(x, y, length) {
  var p = {
    x: x,
    y: y,
    length: length,
    draw: function() {
      fill(255, 0, 255);
      rect(this.x, this.y, this.length, 20);
    },
    checkContact: function(gc_x, gc_y) {
      if (gc_x > this.x && gc_x < this.x + this.length) {
        var d = this.y - gc_y;
        if (d >= 0 && d < 5) {
          return true;
        }

      }
      return false;
    }
  }

  return p;
}

//function keyPressed()
//{
//    jumpSound.play();
//}
